function enter(pi) {
	pi.openNpc(pi.getPortal().getId(), "传送_大海中央");
	return true;
}
