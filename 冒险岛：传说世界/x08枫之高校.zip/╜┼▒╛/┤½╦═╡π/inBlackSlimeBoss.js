function enter(pi) {
	pi.openNpc(1082102, 0);
	return true;
}
