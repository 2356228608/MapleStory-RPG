﻿var status = 0;

function start() {
	status = -1;
	action(1, 0, 0);
}
function action(mode, type, selection) {
		cm.sendOk("怎么样，金海滩不错吧？下次来这里旅游记得还选我的航班啊！");
		cm.dispose();
}
