﻿/* Dawnveil
Made by Daenerys
 */
var status = -1;

function action(mode, type, selection) {
	cm.sendOk("哼哼，邪恶的地鼠王会被我们再一次打倒的！");
	cm.dispose();
}
