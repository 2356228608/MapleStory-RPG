﻿var status = -1;

function start() {
	action(1, 0, 0);
}

function action(mode, type, selection) {
	cm.dispose();
	cm.openNpc(9330193, "枫之高校_好感兑换");
}
