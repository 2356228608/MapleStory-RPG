/* 列娜海峡
Made by Jessefjxm
 */
var status = -1;
function action(mode, type, selection) {
	status++;
	ms.fieldEffect_ScreenMsg("Map/Effect.img/temaD/enter/glacierExplorer");
	ms.dispose();
}
