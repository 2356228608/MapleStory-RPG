﻿/* Dawnveil
Made by Daenerys
 */
var status = -1;

function action(mode, type, selection) {
	cm.sendOk("我也要扮演主角！");
	cm.dispose();
}
