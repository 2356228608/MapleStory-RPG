﻿/* 
Made by jessefjxm
 */
var status = -1;

function action(mode, type, selection) {
	cm.sendOk("汪！");
	cm.dispose();
}
