﻿function act() {
	if (rm.isQuestActive(37174)) {
		rm.dropSingleItem(4036504);
	} else if (rm.isQuestActive(37176)) {
		rm.dropSingleItem(4036507);
	}
}
