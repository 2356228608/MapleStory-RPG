﻿function enter(pi) {
	if (pi.isQuestActive(30073)) {
		pi.warp(106031300, 0);
	} else {
		pi.warp(106030210, 0);
	}
	return true;
}
