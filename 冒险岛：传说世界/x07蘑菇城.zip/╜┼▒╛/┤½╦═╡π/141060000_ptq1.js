function enter(pi) {
	pi.openNpc(1510006, "副本_列娜海峡_迷路的诺拉");
	return true;
}
