﻿/* 鲁塔比斯入口
Made by Jessefjxm
 */
function enter(pi) {
	pi.warp(910700200, 0);
    return true;
}
