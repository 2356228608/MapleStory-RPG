/*
 * 起源之塔
 * by Jessefjxm
 */
 
function enter(pi) {
	pi.openNpc(1, "起源之塔_34F_传送");
	return true;
}
