﻿/* 
Made by jessefjxm
 */
var status = -1;

function action(mode, type, selection) {
	cm.sendOk("昂昂~");
	cm.dispose();
}
