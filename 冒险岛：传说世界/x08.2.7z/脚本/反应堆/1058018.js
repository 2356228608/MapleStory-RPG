﻿function act() {
    //var em = rm.getEventManager("BloodyBoss");
    //em.setProperty("stage0", parseInt(em.getProperty("stage0")) + 1);
    //if (em != null && em.getProperty("stage0").equals("1")) {
    rm.spawnMonster(8920000, 1);
    //em.setProperty("stage0", parseInt(em.getProperty("stage0")) + 1);
    // }else if(em != null && em.getProperty("stage0").equals("2")){
 //   rm.spawnMonster(8920101, 1);
    //  em.setProperty("stage0", parseInt(em.getProperty("stage0")) + 1);
    // }else if(em != null && em.getProperty("stage0").equals("3")){
   // rm.spawnMonster(8920102, 1);
    //   em.setProperty("stage0", parseInt(em.getProperty("stage0")) + 1);
    // }else if(em != null && em.getProperty("stage0").equals("4")){
   // rm.spawnMonster(8920103, 1);
    // }
}