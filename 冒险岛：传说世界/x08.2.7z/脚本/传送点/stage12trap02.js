/* 起源之塔
Made by Jessefjxm
 */
function enter(pi) {
	pi.warp(992012000, 2);
	pi.addPopupSay(2540000, 6000, "当心！那有陷阱。这次你试着从别的方向通过吧。");
	return true;
}
