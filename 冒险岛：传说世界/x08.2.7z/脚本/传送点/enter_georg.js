function enter(pi) {
	pi.openNpc(1510007, 0);
	return true;
}
