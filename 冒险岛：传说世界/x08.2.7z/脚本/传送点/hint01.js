function enter(pi) {
	pi.openNpc(1, "起源之塔_23F_提示");
    return true;
}
