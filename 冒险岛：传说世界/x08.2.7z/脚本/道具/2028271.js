function start() {
	im.openNpc(im.getItemId(), "道具_阿丽莎戒指箱");
	im.dispose();
}
