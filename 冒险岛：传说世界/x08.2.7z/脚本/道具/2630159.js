﻿/*
 *  @Author Jessefjxm
 */
// 全局变量
var status = -1; // status: 当前聊天交互轮数
// 开头
function start() {
	action(1, 0, 0);
}

function action(mode, type, selection) {
	im.dispose();
	im.openNpc(1501016);
}
