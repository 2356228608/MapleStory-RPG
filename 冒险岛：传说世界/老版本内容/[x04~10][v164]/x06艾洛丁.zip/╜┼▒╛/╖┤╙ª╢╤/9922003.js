function act() {
	rm.dropSingleItem(4000136);
}
