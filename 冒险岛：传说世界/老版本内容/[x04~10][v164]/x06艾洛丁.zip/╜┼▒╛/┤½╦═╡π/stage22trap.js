function enter(pi) {
	pi.warp(992022000, 0);
	pi.addPopupSay(2540000, 6000, "唉……好危险啊。还好我的力量可以把你带到这里来。小心别坠落了。");
    return true;
}
