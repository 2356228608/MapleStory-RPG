/*
 *  功能：测试
 *  @Author Jessefjxm
 */

// 开头
function start() {
	im.dispose();
	im.openNpc(0,"测试");
}

function action(mode, type, selection) {
	im.dispose();
	im.openNpc(0,"测试");
}
