﻿function start() {
	im.openNpc(im.getItemId(), "道具_成长秘药");
	im.dispose();
}
