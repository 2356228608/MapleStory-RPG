function enter(pi) {
	pi.openNpc(3, "起源之塔_24F_猜音乐");
    return true;
}
