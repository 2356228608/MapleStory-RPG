function enter(pi) {
	pi.openNpc(1510006, 0);
	return true;
}
