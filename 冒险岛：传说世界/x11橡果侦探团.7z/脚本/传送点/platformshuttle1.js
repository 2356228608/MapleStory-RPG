function enter(pi) {
	pi.openNpc(1,"控制之神_18关_反复跳");
	return true;
}