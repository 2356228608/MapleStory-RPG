function enter(pi) {
	pi.openNpc(pi.getMapId(), "传送_迷失艾洛丁");
	return true;
}
