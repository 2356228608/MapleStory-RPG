﻿function enter(pi) {
	pi.openNpc(0, "副本_狮子王城_第五座塔");
	return true;
}
