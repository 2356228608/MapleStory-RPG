﻿function enter(pi) {
    pi.openNpc(1064012);
    return true;
}