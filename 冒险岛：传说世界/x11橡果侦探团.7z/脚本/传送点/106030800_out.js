﻿function enter(pi) {
	pi.openNpc(1000000, "蘑菇城_Boss_离开");
	return true;
}
