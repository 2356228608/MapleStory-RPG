﻿function enter(pi) {
	pi.openNpc(0, "副本_狮子王城_第二座塔");
	return true;
}
