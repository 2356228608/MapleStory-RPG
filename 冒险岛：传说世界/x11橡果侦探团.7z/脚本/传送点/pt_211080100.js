﻿function enter(pi) {
	pi.openNpc(0, "副本_狮子王城_玫瑰花园");
	return true;
}
