function enter(pi) {
	pi.openNpc(pi.getPortal().getId(), "传送_进入艾洛丁");
	return true;
}
