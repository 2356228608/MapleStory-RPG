﻿function enter(pi) {
	pi.openNpc(0, "控制之神_完成");
	return true;
}
