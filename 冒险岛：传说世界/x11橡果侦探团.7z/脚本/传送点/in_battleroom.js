﻿function enter(pi) {
	pi.openNpc(9062147, "小游戏_大冒险钻头");
	return true;
}
