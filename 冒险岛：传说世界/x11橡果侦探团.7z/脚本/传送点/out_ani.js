﻿function enter(pi) {
	pi.openNpc(2161010);
	return true;
}
