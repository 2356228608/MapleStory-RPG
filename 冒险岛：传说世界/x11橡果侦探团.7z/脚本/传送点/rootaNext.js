﻿function enter(pi) {
	pi.warp(pi.getPlayer().getMapId() + 10, 0);
	return true;
}
