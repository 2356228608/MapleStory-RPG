function enter(pi) {
	pi.openNpc(2540000, "副本_起源之塔");
    return true;
}
