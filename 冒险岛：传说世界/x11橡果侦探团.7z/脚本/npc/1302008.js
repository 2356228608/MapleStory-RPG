﻿/* global ms */
var status = -1;

function action(mode, type, selection) {
	if (mode === 0) {
		status--;
	} else {
		status++;
	}
	cm.warp(106030103, 0);
	cm.dispose();
}
