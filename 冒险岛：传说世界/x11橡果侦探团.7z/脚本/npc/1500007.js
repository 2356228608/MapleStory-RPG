﻿/* Dawnveil
Made by Daenerys
 */
var status = -1;

function action(mode, type, selection) {
	cm.sendOk("噢噢……我也要变得跟你一样厉害！");
	cm.dispose();
}
