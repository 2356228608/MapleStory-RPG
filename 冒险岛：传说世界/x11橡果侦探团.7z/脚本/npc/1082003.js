﻿var status = 0;

function start() {
	status = -1;
	action(1, 0, 0);
}
function action(mode, type, selection) {
		cm.sendOk("电灯……音响……这回可别再坏了！");
		cm.dispose();
}
