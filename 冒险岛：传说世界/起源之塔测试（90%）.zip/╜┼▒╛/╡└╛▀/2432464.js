function start() {
	im.openNpc(im.getItemId(), "道具_起源点数");
	im.dispose();
}
