﻿function action(mode, type, selection) {
	//ms.getMap().spawnNpc(2161000, new java.awt.Point(-4, -181));
	// 让npc朝向左边
}
