﻿/* Dawnveil
Made by Daenerys
 */
var status = -1;

function action(mode, type, selection) {
	cm.sendOk("怎么样，这样我表演你像吗？");
	cm.dispose();
}
