﻿/* Dawnveil
Made by Daenerys
 */
var status = -1;

function action(mode, type, selection) {
	cm.sendOk("我们正在排练新的话剧！以你为原型哦！");
	cm.dispose();
}
