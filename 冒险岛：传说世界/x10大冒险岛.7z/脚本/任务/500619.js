﻿var status = -1;
var selectionLog = new Array(); // 记录每一轮的选择

function start(mode, type, selection) {
	if (status == 0 && mode == 0) {
		qm.dispose();
		return;
	}
	(mode == 1) ? status++ : status--;
	var i = -1;
	selectionLog[status] = selection;
	if (status <= i++) {
		qm.dispose();
	} else if (status === i++) {
		qm.askMenu("#b#e<大冒险等级>每周奖励！#n#k\r\n\r\n- 当前<大冒险等级>：#b初级（6级）#k\r\n#r（每周奖励从中级（5级）以上开始可以获得）#k\r\n#L1# #b查看<大冒险等级>每周奖励列表#l#k", 9062143);
	} else if (status === i++) {
		qm.sendOk("\r\n#e<大冒险等级>每周奖励列表#n\r\n#b\r\n  #i2450141:#  #t2450141:# 5个（7天）\r\n  #i2023654:#  #t2023654:# 5个（7天）\r\n  #i2023672:#  #t2023672:# 5个（7天）\r\n #i2436078:# #t2436078:# 5个（7天）\r\n  #i2435924:#  #t2435924:# 1个（7天）\r\n  #i2434921:#  #t2434921:# 1个（7天）\r\n #i2434288:#  #t2434288:# 5个（7天）\r\n #i4001864:#  #t4001864:# 5个（7天）\r\n  #i2434917:#   #t2434917:# 5个（7天）\r\n  #i2630181:#   #t2630181:# 50个（7天）\r\n  #i1712001:#  #t1712001:# 10个\r\n  #i1712002:#  #t1712002:# 10个\r\n  #i1712003:#  #t1712003:# 10个\r\n  #i1712004:#  #t1712004:# 10个\r\n  #i1712005:#  #t1712005:# 10个\r\n  #i1712006:#  #t1712006:# 10个", 9062143);
	} else if (status == i++) {
		qm.dispose();
	}
}

function end(mode, type, selection) {
	(mode == 1) ? status++ : status--;
	var i = -1;
	if (status <= i++) {
		qm.dispose();
	} else if (status == i++) {
		qm.dispose();
	}
}
