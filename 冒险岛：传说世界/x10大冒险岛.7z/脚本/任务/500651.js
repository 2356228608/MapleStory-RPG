﻿var status = -1;
var selectionLog = new Array(); // 记录每一轮的选择

function start(mode, type, selection) {
	if (status == 0 && mode == 0) {
		qm.dispose();
		return;
	}
	(mode == 1) ? status++ : status--;
	var i = -1;
	selectionLog[status] = selection;
	if (status <= i++) {
		qm.dispose();
	} else if (status === i++) {
		qm.askMenu("在#b<操作之神>#k中展现你的#e#b韧性#k#n吧！\r\n\r\n在<操作之神>中#b通关20关以上#k的周数达到#b5周以上#k时，可以获得#b#t2630132:##k！\r\n\r\n#e[通关20关以上周数]#n\r\n#b0 / 11次#k\r\n\r\n#e[通关20关以上周数达到5周奖励]#n\r\n#b#i2630132:# #t2630132:##k\r\n\r\n#b#L0# 查看每周通关记录详情#k#l", 9062148);
	} else if (status === i++) {
		qm.sendOk("#e[每周通关记录]#n\r\n\r\n1周：通关0关#r（未达成）#k\r\n2周：通关0关#r（未达成）#k\r\n3周：通关0关#r（未达成）#k\r\n", 9062148);
	} else if (status == i++) {
		qm.dispose();
	}
}

function end(mode, type, selection) {
	(mode == 1) ? status++ : status--;
	var i = -1;
	if (status <= i++) {
		qm.dispose();
	} else if (status == i++) {
		qm.dispose();
	}
}
