function start() {
	im.gainItem(4310266, 1);
	im.gainItem(im.getItemId(), -1);
	im.dispose();
}
