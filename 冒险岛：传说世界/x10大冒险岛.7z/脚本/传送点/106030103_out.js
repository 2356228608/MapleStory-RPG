﻿function enter(pi) {
	pi.warp(106030102, 0);
	return true;
}
