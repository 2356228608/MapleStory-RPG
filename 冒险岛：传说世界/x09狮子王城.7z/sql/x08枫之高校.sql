-- ----------------------------
-- 任务
-- ----------------------------
UPDATE `wz_questdata` SET `autoStart`='1' WHERE (`questid`='52348');
UPDATE `wz_questdata` SET `autoStart`='1' WHERE (`questid`='52349');
UPDATE `wz_questdata` SET `autoStart`='1' WHERE (`questid`='52350');
UPDATE `wz_questdata` SET `autoStart`='1' WHERE (`questid`='52351');
UPDATE `wz_questdata` SET `autoStart`='1' WHERE (`questid`='52352');
UPDATE `wz_questdata` SET `autoStart`='1' WHERE (`questid`='52353');
UPDATE `wz_questdata` SET `autoStart`='1' WHERE (`questid`='52354');
UPDATE `wz_questdata` SET `autoStart`='1' WHERE (`questid`='52355');
UPDATE `wz_questdata` SET `autoStart`='1' WHERE (`questid`='52356');
UPDATE `wz_questdata` SET `autoStart`='1' WHERE (`questid`='52357');
UPDATE `wz_questdata` SET `autoStart`='1' WHERE (`questid`='52358');
UPDATE `wz_questdata` SET `autoStart`='1' WHERE (`questid`='52359');
UPDATE `wz_questdata` SET `autoStart`='1' WHERE (`questid`='52360');
UPDATE `wz_questdata` SET `autoStart`='1' WHERE (`questid`='52361');
UPDATE `wz_questdata` SET `autoStart`='1' WHERE (`questid`='52362');
UPDATE `wz_questdata` SET `autoStart`='1' WHERE (`questid`='52363');
UPDATE `wz_questdata` SET `autoStart`='1' WHERE (`questid`='52364');
UPDATE `wz_questdata` SET `autoStart`='1' WHERE (`questid`='52365');
UPDATE `wz_questdata` SET `autoStart`='1' WHERE (`questid`='52366');
-- ----------------------------
-- 商店
-- ----------------------------
REPLACE INTO `shops` VALUES ('9330342', '9330342');
-- ----------------------------
-- 商店物品
-- ----------------------------
REPLACE INTO `shopitems` VALUES ('11282934', '9330342', '1202094', '0', '4310105', '500', '0', '1', '1', '1', '0', '0', '0');
REPLACE INTO `shopitems` VALUES ('11282935', '9330342', '1202095', '0', '4310105', '500', '0', '2', '1', '1', '0', '0', '0');
REPLACE INTO `shopitems` VALUES ('11282936', '9330342', '1202096', '0', '4310105', '500', '0', '3', '1', '1', '0', '0', '0');
REPLACE INTO `shopitems` VALUES ('11282937', '9330342', '1202097', '0', '4310105', '500', '0', '4', '1', '1', '0', '0', '0');
REPLACE INTO `shopitems` VALUES ('11282938', '9330342', '1162019', '0', '4310105', '1000', '0', '5', '1', '1', '0', '0', '0');
REPLACE INTO `shopitems` VALUES ('11282939', '9330342', '1162020', '0', '4310105', '1000', '0', '6', '1', '1', '0', '0', '0');
REPLACE INTO `shopitems` VALUES ('11282940', '9330342', '1162021', '0', '4310105', '1000', '0', '7', '1', '1', '0', '0', '0');
REPLACE INTO `shopitems` VALUES ('11282941', '9330342', '1162022', '0', '4310105', '1000', '0', '8', '1', '1', '0', '0', '0');

-- ----------------------------
-- 怪物掉落
-- ----------------------------

REPLACE INTO `drop_data` VALUES ('28679', '9410151', '', '1202004', '', '1', '1', '0', '1000');
REPLACE INTO `drop_data` VALUES ('28680', '9410150', '', '1202003', '', '1', '1', '0', '1000');
REPLACE INTO `drop_data` VALUES ('28681', '9410149', '', '1202002', '', '1', '1', '0', '1000');
REPLACE INTO `drop_data` VALUES ('28682', '9410148', '', '1202001', '', '1', '1', '0', '1000');
REPLACE INTO `drop_data` VALUES ('28683', '9410147', '', '1202000', '', '1', '1', '0', '1000');
