﻿/*
 * 2431151	陈旧的回城卷轴
 */

function start() {
	// 最好能加点特效
	im.warp(910700000, 0);
	im.gainItem(2431151, -1);
	im.dispose();
}
