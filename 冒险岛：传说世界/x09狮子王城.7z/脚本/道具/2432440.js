﻿function start() {
	im.openNpc(im.getItemId(), "道具_朦胧石");
	im.dispose();
}
