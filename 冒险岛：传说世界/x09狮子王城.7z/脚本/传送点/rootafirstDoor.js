﻿function enter(pi) {
    pi.openNpc(1064013);
    return true;
}