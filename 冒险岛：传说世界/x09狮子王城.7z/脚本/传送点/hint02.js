function enter(pi) {
	pi.openNpc(2, "起源之塔_23F_提示");
    return true;
}
