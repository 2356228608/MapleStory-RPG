function enter(pi) {
	pi.warp(pi.getMapId(), 2);
	pi.addPopupSay(2540000, 5000, "该死！有陷阱。让我们绕过这里从别处走吧。");
    return true;
}
