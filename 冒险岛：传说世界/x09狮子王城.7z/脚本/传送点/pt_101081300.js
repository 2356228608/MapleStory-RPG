function enter(pi) {
	if (pi.isQuestFinished(37158)) {
		pi.warp(101082000, 1);
	}else{
		pi.playerMessage(5, "这地方看着好不对劲……还是不要乱闯了吧……");
	}
	return true;
}
