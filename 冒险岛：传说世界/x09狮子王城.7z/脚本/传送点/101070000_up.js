function enter(pi) {
    pi.openNpc(1500010);
    return true;
}