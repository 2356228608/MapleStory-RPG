function enter(pi) {
	pi.warp(pi.getMapId(), 1);
	return true;
}
