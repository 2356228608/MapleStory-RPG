/*
Made by Jessefjxm
 */
var status = -1;

function action(mode, type, selection) {
	ms.fieldEffect_ScreenMsg("Map/Effect.img/temaD/enter/lionCastle");
	ms.dispose();
}
