﻿function action(mode, type, selection) {
}
