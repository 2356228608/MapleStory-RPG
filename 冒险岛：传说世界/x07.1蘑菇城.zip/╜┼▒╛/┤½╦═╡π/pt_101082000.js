function enter(pi) {
	pi.openNpc(0, "副本_艾洛丁_阁楼");
	return true;
}
