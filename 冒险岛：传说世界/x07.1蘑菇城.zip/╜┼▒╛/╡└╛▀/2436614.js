﻿function start() {
	im.openNpc(im.getItemId(), "道具_获取金币");
	im.dispose();
}
