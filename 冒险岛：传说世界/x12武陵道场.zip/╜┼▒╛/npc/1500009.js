﻿/* Dawnveil
Made by Daenerys
 */
var status = -1;

function action(mode, type, selection) {
	cm.sendOk("多亏了你的帮助！孩子们都很感激你。");
	cm.dispose();
}
