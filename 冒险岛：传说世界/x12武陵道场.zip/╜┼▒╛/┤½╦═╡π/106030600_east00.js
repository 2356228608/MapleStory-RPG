﻿function enter(pi) {
	pi.openNpc(0, "副本_蘑菇城_Boss");
	return true;
}
