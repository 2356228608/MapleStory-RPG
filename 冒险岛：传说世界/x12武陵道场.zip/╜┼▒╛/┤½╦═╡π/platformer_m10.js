function enter(pi) {
	pi.openNpc(10,"控制之神_12关_跳远");
	return true;
}