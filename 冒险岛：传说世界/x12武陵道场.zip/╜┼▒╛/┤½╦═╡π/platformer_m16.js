function enter(pi) {
	pi.openNpc(16,"控制之神_12关_跳远");
	return true;
}