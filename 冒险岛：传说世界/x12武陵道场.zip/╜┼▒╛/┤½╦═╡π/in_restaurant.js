﻿function enter(pi) {
	pi.warp(993080100,0);
	return true;
}
