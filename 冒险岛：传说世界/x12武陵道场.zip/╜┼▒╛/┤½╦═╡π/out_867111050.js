function enter(pi) {
	var id = pi.getPortal().getId();
	var name = pi.getPortal().getName();
	pi.playerMessage(5, "还没张贴完传单呢。还是不要离开的好。");
}
