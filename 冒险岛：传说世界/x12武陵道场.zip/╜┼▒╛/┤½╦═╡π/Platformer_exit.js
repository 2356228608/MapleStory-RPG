﻿/*返回到以前的地图
 */

function enter(pi) {
	pi.warp(993080000, 1);
	return true;
}
