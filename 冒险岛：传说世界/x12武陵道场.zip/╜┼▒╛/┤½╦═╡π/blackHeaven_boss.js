﻿function enter(pi) {
    pi.openNpc(1540446, "副本_黑色天堂_Boss");
}