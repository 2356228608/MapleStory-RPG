﻿function enter(pi) {
    pi.openNpc(0, "副本_枫之高校");
    return true;
}