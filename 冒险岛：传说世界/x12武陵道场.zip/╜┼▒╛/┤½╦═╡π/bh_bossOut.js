﻿function enter(pi) {
    pi.openNpc(1540496, "副本_黑色天堂_Boss");
    return true;
}