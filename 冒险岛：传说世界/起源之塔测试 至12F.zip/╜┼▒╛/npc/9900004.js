﻿var status = 0;

var eff = "#fEffect/CharacterEff/1112905/0/1#"; //
var epp = "#fEffect/CharacterEff/1082312/0/0#"; //彩光
var epp1 = "#fEffect/CharacterEff/1082312/2/0#"; //彩光1
var axx = "#fEffect/CharacterEff/1051294/0/0#"; //爱心
var xxx = "#fEffect/CharacterEff/1082565/2/0#"; //星系
var ppp = "#fEffect/CharacterEff/1112907/4/0#"; //泡炮
var epp3 = "#fEffect/CharacterEff/1112908/0/1#"; //彩光3
var axx1 = "#fEffect/CharacterEff/1062114/1/0#"; //爱心
var zs = "#fEffect/CharacterEff/1112946/2/0#"; //砖石粉
var zs1 = "#fEffect/CharacterEff/1112946/1/1#"; //砖石蓝
var dxxx = "#fEffect/CharacterEff/1102232/2/0#"; //星系
var tz1 = "#fEffect/CharacterEff/1082565/2/0#"; //兔子蓝
var tz = "#fEffect/CharacterEff/1082565/4/0#"; //兔子粉
var tz5 = "#fUI/UIWindow2.img/QuestAlarm/BtQ/normal/0#";
var iconEvent = "#fUI/UIToolTip.img/Item/Equip/Star/Star#";
var ttt2 = "#fUI/UIWindow/Quest/icon6/7#"; ////美化2
var tz2 = "#fEffect/CharacterEff/1082565/0/0#"; //兔子灰色
var tz3 = "#fEffect/CharacterEff/1082588/0/0#"; //红点
var tz4 = "#fEffect/CharacterEff/1082588/3/0#"; //蓝点
var tz51 = "#fEffect/CharacterEff/1082588/1/0#"; //绿点
var tz6 = "#fEffect/CharacterEff/1112900/2/1#"; //音符蓝
var tz7 = "#fEffect/CharacterEff/1112900/3/1#"; //音符红
var tz8 = "#fEffect/CharacterEff/1112900/4/1#"; //音符绿
var tz88 = "#fEffect/CharacterEff/1112900/5/1#"; //音符绿!
var tz9 = "#fEffect/CharacterEff/1112902/0/0#"; //蓝心
var tz10 = "#fEffect/CharacterEff/1112903/0/0#"; //红心
var tz11 = "#fEffect/CharacterEff/1112904/0/0#"; //彩心
var tz12 = "#fEffect/CharacterEff/1112924/0/0#"; //黄星
var tz13 = "#fEffect/CharacterEff/1112925/0/0#"; //蓝星
var tz14 = "#fEffect/CharacterEff/1112926/0/0#"; //红星
var tz15 = "#fEffect/CharacterEff/1112949/0/0#"; //花样音符
var tz16 = "#fEffect/CharacterEff/1112949/1/0#"; //花样音符
var tz17 = "#fEffect/CharacterEff/1112949/2/0#"; //花样音符
var tz18 = "#fEffect/CharacterEff/1112949/3/0#"; //花样音符
var tz19 = "#fEffect/CharacterEff/1112949/4/0#"; //花样音符
var tz20 = "#fEffect/CharacterEff/1114000/1/0#"; //红星花
var yun = "#fUI/UIWindow/PartySearch2/BtNext/mouseOver/0#"; ////红沙漏
var wn1 = "#fUI/Basic.img/BtClaim/normal/0#"; //警灯
var wn2 = "#fUI/UIWindowTW.img/TimeCapsule/BtClose/disabled/0#"; //叉叉
var wn3 = "#fUI/Basic.img/ComboBox/disabled/1#"; //白条
var wn4 = "#fUI/Basic.img/ComboBox3/mouseOver/1#"; //黄条
var wn5 = "#fUI/Basic.img/Cursor/17/16#"; //黄色圈
var wn6 = "#fUI/Basic.img/Cursor/34/0#"; //圈
var wn7 = "#fUI/Basic.img/Cursor/43/3#"; //蓝圈
var wn8 = "#fUI/CashShop.img/CSBargainSale/BtLeft/normal/0#"; //黄色左
var wn9 = "#fUI/CashShop.img/CSBargainSale/BtRight/normal/0#"; //黄色右
var wn10 = "#fUI/CashShop.img/CSBeauty/tip/hair#"; //发型提示
var wn11 = "#fUI/CashShop.img/CSBeauty/hairColor/Enable/0#"; //黑
var wn12 = "#fUI/CashShop.img/CSBeauty/hairColor/Enable/1#"; //红
var wn13 = "#fUI/CashShop.img/CSBeauty/hairColor/Enable/2#"; //橙
var wn14 = "#fUI/CashShop.img/CSBeauty/hairColor/Enable/3#"; //黄
var wn15 = "#fUI/CashShop.img/CSBeauty/hairColor/Enable/4#"; //绿
var wn16 = "#fUI/CashShop.img/CSBeauty/hairColor/Enable/5#"; //亲
var wn17 = "#fUI/CashShop.img/CSBeauty/hairColor/Enable/6#"; //紫
var wn18 = "#fUI/CashShop.img/CSBeauty/hairColor/Enable/7#"; //褐
var wn19 = "#fUI/CashShop.img/CSEffect/event/0#"; //活动图标
var wn20 = "#fUI/CashShop.img/CSEffect/hot/0#"; //人气图标
var wn21 = "#fUI/CashShop.img/CSEffect/mileage/0#"; //积分图标
var wn22 = "#fUI/CashShop.img/CSEffect/new/0#"; //新品图标
var wn23 = "#fUI/CashShop.img/CSEffect/sale/0#"; //折扣图标
var wn24 = "#fUI/CashShop.img/CSEffect/time/0#"; //限量图标
var wp1 = "#fUI/CashShop.img/CSEffect/number/0#"; //数字 后面改数字0-9
var wp2 = "#fUI/CashShop.img/CSIcon/0#"; //男图标 0男-1女
var wp3 = "#fUI/CashShop.img/CSStatus/BtCharge/mouseOver/0#"; //充值图标
var wp4 = "#fUI/CashShop.img/CSSubTabBar/Tab/4/Disable/0#"; //武器开头
var wp5 = "#fUI/CashShop.img/CSSubTabBar/Tab/4/Disable/1#"; //帽子
var wp6 = "#fUI/CashShop.img/CSSubTabBar/Tab/4/Disable/2#"; //披风
var wp7 = "#fUI/CashShop.img/CSSubTabBar/Tab/4/Disable/3#"; //长袍
var wp8 = "#fUI/CashShop.img/CSSubTabBar/Tab/4/Disable/4#"; //上衣
var wp9 = "#fUI/CashShop.img/CSSubTabBar/Tab/4/Disable/5#"; //裤子
var wp10 = "#fUI/CashShop.img/CSSubTabBar/Tab/4/Disable/6#"; //鞋子
var wp11 = "#fUI/CashShop.img/CSSubTabBar/Tab/4/Disable/7#"; //手套
var wp12 = "#fUI/CashShop.img/CSSubTabBar/Tab/4/Disable/8#"; //饰品
var wp13 = "#fUI/CashShop.img/CSSubTabBar/Tab/4/Disable/9#"; //眼饰
var wp14 = "#fUI/CashShop.img/CSSubTabBar/Tab/4/Disable/10#"; //效果结尾
var wp15 = "#fUI/mapleBingo.img/mapleBingo/lineAni/0/0#"; //斜线美化
var wp16 = "#fUI/mapleBingo.img/mapleBingo/lineAni/0/1#"; //斜线美化
var wp17 = "#fUI/mapleBingo.img/mapleBingo/lineAni/0/2#"; //斜线美化
var wp18 = "#fUI/mapleBingo.img/mapleBingo/lineAni/0/3#"; //斜线美化
var wp19 = "#fUI/mapleBingo.img/mapleBingo/lineAni/0/4#"; //斜线美化
var wp20 = "#fUI/mapleBingo.img/mapleBingo/lineAni/0/5#"; //斜线美化
var wi1 = "#fUI/SoulUI.img/DungeonMap/icon/dungeonItem/0#"; //星星图标
var wi2 = "#fUI/SoulUI.img/DungeonMap/icon/soulFragment/0#"; //菱形图标
var wi3 = "#fUI/SoulUI.img/DungeonMap/icon/soulTrap/0#"; //骷髅图标
var wi4 = "#fUI/SoulUI.img/DungeonMap/icon/warpGate/0#"; //圆点图标
var wi5 = "#fUI/SoulUI.img/DungeonParty/backgrnd2#"; //毛莫
var wi6 = "#fUI/StarCityUI.img/Board_Friend/list/0/5/selected#"; //剪刀石头布
var wi7 = "#fUI/StarCityUI.img/Board_GameRank/tab/enabled/0#"; //游戏排行
var wi8 = "#fUI/StarCityUI.img/Board_GameRank/user/myrank#"; //黄色条
var wi9 = "#fUI/StarCityUI.img/Board_GameRank/user/shining#"; //紫色条
var wi11 = "#fUI/UIPVP.img/ChampionMark/4#"; //徽章黄色
var wi12 = "#fUI/UIPVP.img/DmgEffect/DmgRed/excellentCritical#"; //特别危险蓝
var wi13 = "#fUI/UIPVP.img/DmgEffect/DmgBlue/excellentCritical#"; //特别危险绿
var wi14 = "#fUI/UIPVP.img/MiniMapIcon/star#"; //黄星星
var wi15 = "#fUI/UIToolTip.img/Item/Equip/Star/Star1#"; //蓝星星
var yun1 = "#fUI/UIWindow/Quest/icon7/10#"; ////红色圆
var d13 = "#fUI/UIWindowBT.img/WorldMap/BtHome/normal/0#"; //房子
var d14 = "#fUI/UIWindowBT.img/WorldMap/Btnavi/normal/0#"; //湾箭头
var f9 = "#fUI/UIWindowBT.img/WorldMap/BtAnother/normal/0#"; //蓝方星星
var d10 = "#fUI/UIWindow.img/Shop/meso#"; //金币图标
var p3 = "#fUI/Basic.img/BtCoin/normal/0#";

var ca = java.util.Calendar.getInstance();
var year = ca.get(java.util.Calendar.YEAR); //获得年份
var month = ca.get(java.util.Calendar.MONTH) + 1; //获得月份
var day = ca.get(java.util.Calendar.DATE); //获取日
var hour = ca.get(java.util.Calendar.HOUR_OF_DAY); //获得小时
var minute = ca.get(java.util.Calendar.MINUTE); //获得分钟
var second = ca.get(java.util.Calendar.SECOND); //获得秒
var weekday = ca.get(java.util.Calendar.DAY_OF_WEEK);

function start() {
	status = -1;
	action(1, 0, 0);
}

function action(mode, type, selection) {
	if (status == 0 && mode == 0) {
		cm.dispose();
		return;
	}
	if (mode == 1) {
		status++;
	} else {
		status--;
	}
	if (cm.getMapId() == 180000001) {
		cm.sendOk("很遗憾，您因为违反用户守则被禁止游戏活动，如有异议请联系管理员.");
		cm.dispose();
	} else if (status == 0) {

		var selStr = "";
		var n = "\r\n";

		//selStr= "   " + tz + "#d在线：#r" + cm.getPlayer().getTodayOnlineTime() + "#d 分钟 " + tz + "累计充值：#r" + cm.getTotalRMB() + "#d 元 " + tz + "消费币：#r" + cm.getHyPay(1) + "#d \r\n   " + tz + "点卷：#r" + cm.getPlayer().getCSPoints(1) + "#d\t" + tz + "抵用券：#r" + cm.getPlayer().getCSPoints(2) + "#k\r\n   " + tz + "#d废弃积分为：#r" + cm.getPlayerPoints() + "#k点      #e#d当前时间" + hour + ":" + minute + ":" + second + "#k\r\n"
		selStr += " " + tz + "#b在线：#r" + cm.getPlayer().getTodayOnlineTime() + "#b 分钟 ";
		selStr += " " + tz + "#b点卷：#r" + cm.getPlayer().getCSPoints(1);
		selStr += " " + tz + "#b抵用券：#r" + cm.getPlayer().getCSPoints(2);
		//selStr+= " " + tz + "#b消费币：#r" + cm.getHyPay(1);
		if (cm.getPlayer().getIntNoRecord(99997) == 1) {
			tz14 = wi14;
			n = n;
		}
		selStr += n;
		selStr += "#L6666##b" + tz14 + "测试功能#l";
		selStr += n;
		selStr += "#L1##b" + tz14 + "返回市场#l#L199#" + tz14 + "NPC 地图#l#L130#" + tz14 + "娱乐花园#l#L200#" + tz14 + "进入商城#l"; //
		selStr += n;
		selStr += "#L0#" + tz14 + "万能传送#l#L8#" + tz14 + "每日签到#l#L555#" + tz14 + "每日任务#l#L225#" + tz14 + "在线奖励#l";
		selStr += n;
		selStr += "#L5#" + tz14 + "所有副本#l#L7#" + tz14 + "所有商店#l#L9#" + tz14 + "删除道具#l#L86#" + tz14 + "新手礼包#l";
		selStr += n;
		selStr += "#L30##b" + tz14 + "转蛋抽奖#l#L20#" + tz14 + "我要变强#l#L85#" + tz14 + "怪怪图鉴#l#L222#" + tz14 + "等级奖励#l";
		selStr += n;
		selStr += "#L111##b" + tz14 + "学习技能#l#L224#" + tz14 + "制作装备#l#L21#" + tz14 + "雇佣管理#l#L56#" + tz14 + "一键转职#l";
		selStr += n;
		selStr += "#L300#" + tz14 + "GM功能#l  #L301#" + tz14 + "美容美发#l#L302#" + tz14 + "印章魔方#l#L55#" + tz14 + "更多服务#l";
		selStr += n;
		selStr += "#L303#" + tz14 + "在线商城#l#L304#" + tz14 + "在线时装#l#L305#" + tz14 + "转生修仙#l#L306#" + tz14 + "会员功能#l";
		selStr += n;
		selStr += "#L307#" + tz14 + "个人信息#l#L308#" + tz14 + "修复日志#l";
		selStr += "#L500#" + tz14 + "黑色天堂#l";
		selStr += "#L501#" + tz14 + "切换拍卖风格#l";
		//selStr+="\r\n";

		//selStr+= ""+ tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "" + tz20 + "\r\n";

		//#r   #L87#"+tz2+"【公告】#k赞助点卷 比例 1 = 5000 QQ群484910040"+tz2+"#l\r\n#r   #L87#"+tz2+"【公告】#kQQ群484910040  找管管领取q 351978885"+tz2+""

		//NPC图片ID,时间(毫秒),"内容"  1540108
		//cm.addPopupSay(1540108, 2000, "欢迎来到[" + cm.getServerName() + "],实力团队运营,独特的新玩法,有什么我能帮到你吗?");
		//cm.askMenu(selStr);
		if (cm.getPlayer().getIntNoRecord(99997) == 0) {
			cm.askMenu(selStr);
		} else {
			cm.askMenu(selStr);
		}
		//cm.askMenu_Bottom(selStr);
		//cm.askMenuS_New(selStr);

	} else if (status == 1) {
		switch (selection) {
		case 501:
			if (cm.getPlayer().getIntNoRecord(99997) == 0) {
				cm.getPlayer().getQuestNAdd(cm.getQuestById(99997)).setCustomData("1");
			} else {
				cm.getPlayer().getQuestNAdd(cm.getQuestById(99997)).setCustomData("0");
			}
			cm.dispose();
			cm.openNpc(9900004);
			break;
		case 500:
			cm.dispose();
			cm.openUI(1103);
			//cm.openNpc(9900004,"冒险岛联盟");
			break;
		case 308:
			cm.dispose();
			var str = cm.getrizhi();
			var logs = str.split("\n"); //以逗号作为分隔字符串
			var text1 = "";
			for (var i = 0; i < logs.length; i++) {
				text1 = text1 + logs[i] + "\r\n";
			}
			cm.sendOk(text1);
			break;
		case 307:
			cm.dispose();
			cm.openNpc(9900004, 1000);
			break;
		case 306:
			cm.dispose();
			cm.openNpc(9400373);
			break;
		case 305:
			cm.dispose();
			cm.openNpc(2091124);
			break;
		case 304:
			cm.dispose();
			cm.openNpc(9000330);
			break;
		case 303:
			cm.dispose();
			cm.openNpc(1052014);
			break;
		case 302:
			cm.dispose();
			cm.openNpc(9310074);
			break;
		case 301:
			cm.dispose();
			cm.openNpc(9310072);
			break;
		case 300:
			cm.dispose();
			cm.openNpc(9310073);
			break;
		case 0:
			cm.dispose();
			cm.openNpc(9900003, 2);
			break;
		case 224:
			cm.dispose();
			cm.openNpc(9900003, 24);
			break;
		case 199:
			cm.dispose(); //450005010
			cm.warp(450005010, 0); //9001014
			break;
		case 198:
			cm.dispose();
			cm.openNpc(9201116);
			break;
		case 30:
			cm.dispose();
			cm.warp(749050400, 0);
			break;
		case 85:
			cm.dispose();
			cm.openUI(596);
			cm.addPopupSay(1540108, 3000, "上线如果发现没有怪怪的,请随便过图就会出现.");
			//cm.openWeb("http://bbs.39mxd.com");
			//cm.sendOk("http://xxxx.com！");
			break;
		case 225:
			cm.dispose();
			cm.openNpc(9900003, 608); //
			break;
		case 222:
			cm.dispose();
			cm.openNpc(9300011, "等级奖励");
			break;
			//case 223:
			// cm.dispose();
			// cm.gainItem(2430505, 1);// HP椅子
			// break;
		case 86:
			cm.dispose();
			cm.openNpc(2008);
			break;
		case 87:
			cm.dispose();
			//cm.openWeb("http://sae.kmmmhh.com/OnlinePay.html?m=34329&g=1143");
			cm.sendOk("已经为您打开充值网站！充值奖励在市场1洞门口NPC领取");
			break;
		case 1:
			if (cm.getMapId() == 910000000) {
				cm.dispose();
				cm.sendOk("您已经在自由市场了。");
			} else {
				cm.dispose();
				cm.warp(910000000, 0);
			}
			break;
		case 55:
			cm.dispose();
			cm.openNpc(9900003, 6);
			break;
		case 56:
			cm.dispose();
			cm.openNpc(9900003, 17);
			break;
		case 5:
			cm.dispose();
			//cm.openNpc(9310071);
			cm.openNpc(9900004, 7);
			break;
		case 555:
			cm.dispose();
			cm.openNpc(9900003, 12);
			break;
		case 7:
			cm.dispose();
			//cm.openNpc(9000345);
			cm.openNpc(9900004, 6);
			break;
		case 8:
			cm.dispose();
			cm.openNpc(9900003, 7);
			break;
		case 9:
			cm.dispose();
			cm.openNpc(9000132, 1);
			break;
		case 20:
			cm.dispose();
			cm.openNpc(9001014);
			break;
		case 278:
			cm.dispose();
			cm.warp(100000104);
			cm.sendOk("点击王子NPC换发型,换眼睛在另一个房间哦!");
			break;
		case 130:
			cm.dispose();
			cm.openNpc(9900004, 99); //股票系统
			//cm.warp(700000000);
			//cm.sendOk("点击王子NPC换发型,换眼睛在另一个房间哦!");
			break;
		case 21:
			cm.dispose();
			cm.openNpc(9030000);
			break;
		case 111:
			cm.dispose();
			cm.openNpc(9900003, 22);
			break;
		case 12:
			cm.dispose();
			cm.openNpc(9900003, 16);
			break;
		case 13:
			cm.dispose();
			cm.openNpc(9900003, 1);
			break;
		case 15:
			cm.dispose();
			cm.openNpc(9900003, 108);
			break;
		case 1231:
			cm.dispose();
			//cm.openNpc(9201116);
			cm.sendOk("#e#r活动时间：2015年8月1日至2015年8月30日！\r\n\r\n#b第一名：全属性戒指100+自选椅子+任选蜡笔3个+50W点卷\r\n第二名：全属性戒指60+大自然椅子+任选蜡笔2个+30W点卷\r\n第三名:全属性戒指40+被驯服的鲸鱼椅子+任选蜡笔1个+20W点卷\r\n第四名至第十名：全属性戒指+滑浪飞船椅子+神秘盒子3个+10W点卷\r\n               #r月底管理员统一发放");
		case 200:
			cm.dispose();
			//cm.openNpc(9900004,100);//股票系统
			cm.EnterCS(); //进入商城
			break;
		case 6666:
			cm.dispose();
			cm.openNpc(0, "测试"); //股票系统
			break;
		}
	}
}
