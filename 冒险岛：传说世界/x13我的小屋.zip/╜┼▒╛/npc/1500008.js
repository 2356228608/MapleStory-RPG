﻿/* Dawnveil
Made by Daenerys
 */
var status = -1;

function action(mode, type, selection) {
	cm.sendOk("这次多亏了你的帮忙啊。");
	cm.dispose();
}
